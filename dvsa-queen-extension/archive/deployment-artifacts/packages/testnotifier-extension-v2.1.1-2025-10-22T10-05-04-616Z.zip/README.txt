TestNotifier - Multi-Pupil DVSA Extension
Version: 2.1.1
Build Date: 2025-10-22T10:05:04.617Z

INSTALLATION INSTRUCTIONS:
1. Open Chrome and navigate to chrome://extensions/
2. Enable "Developer mode" in the top right
3. Click "Load unpacked" and select the extracted extension folder
4. The extension icon should appear in your Chrome toolbar

FEATURES:
✅ Multi-pupil management for driving instructors
✅ Real-time DVSA test slot monitoring
✅ Instant notifications for cancellations
✅ 400+ official test centres database
✅ Professional instructor dashboard
✅ Plan-based usage limits (Free/Starter/Premium/Pro)

MULTI-PUPIL MANAGEMENT:
• Add unlimited pupils (Pro plan)
• Track individual test dates and centres
• Set monitoring preferences per pupil
• View real-time dashboard statistics
• Toggle pupil status (Active/Paused/Inactive)

TEST CENTRE SELECTION:
• Search 400+ official DVSA centres
• Filter by name, city, or postcode
• Select multiple preferred centres
• Visual chips showing selections
• Popular centres suggestions

SETTINGS & CONFIGURATION:
• 24/7 monitoring toggle
• Rapid mode (500ms checks)
• Stealth mode (anti-detection)
• Browser notifications
• Sound alerts

USAGE:
1. Click the extension icon to open popup
2. Add pupils with their test details
3. Select preferred test centres
4. Configure monitoring settings
5. The extension monitors DVSA for cancellations
6. Get instant notifications when slots become available

SAFETY & COMPLIANCE:
• Designed for legitimate instructor use
• Respects DVSA website terms
• No automated booking functionality
• Manual confirmation required for all changes

SUPPORT:
For support and updates, visit testnotifier.co.uk

⚠️  IMPORTANT: This extension is for driving instructors and pupils with legitimate test bookings.
    Always comply with DVSA terms of service and guidelines.

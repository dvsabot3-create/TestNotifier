/**
 * Centralized Motion Constants
 * Matches Figma prototypes and GSAP animations
 */

export const DURATIONS = {
  // Fast interactions
  instant: 0,
  fast: 0.2,
  quick: 0.3,
  
  // Standard animations
  normal: 0.4,
  moderate: 0.5,
  standard: 0.6,
  
  // Entrance animations
  entrance: 0.8,
  slow: 1,
  verySlow: 1.2,
  
  // Special effects
  counter: 2.5,
  
  // Continuous loops
  breathe: 15,
  float: 20,
  floatSlow: 25,
} as const;

export const EASINGS = {
  // Standard easings
  linear: 'none',
  smooth: 'power2.out',
  strong: 'power3.out',
  
  // Bounce/elastic effects
  bounce: 'back.out(1.7)',
  bounceMedium: 'back.out(1.4)',
  bounceSubtle: 'back.out(1.2)',
  
  // Smooth curves
  inOut: 'sine.inOut',
  
  // CSS equivalents
  css: {
    smooth: 'cubic-bezier(0.4, 0, 0.2, 1)',
    bounce: 'cubic-bezier(0.68, -0.55, 0.265, 1.55)',
  },
} as const;

export const STAGGER = {
  // Stagger delays for sequential animations
  tight: 0.05,
  close: 0.1,
  normal: 0.15,
  relaxed: 0.2,
  loose: 0.3,
} as const;

export const DISTANCES = {
  // Movement distances in pixels
  small: {
    y: 20,
    x: 20,
  },
  medium: {
    y: 40,
    x: 40,
  },
  large: {
    y: 60,
    x: 60,
  },
  xlarge: {
    y: 80,
    x: 80,
  },
  xxlarge: {
    y: 100,
    x: 100,
  },
} as const;

export const SCROLL_TRIGGER = {
  // ScrollTrigger start positions
  start: {
    immediate: 'top 100%',
    early: 'top 90%',
    normal: 'top 80%',
    late: 'top 75%',
    center: 'top 50%',
  },
  
  // ScrollTrigger end positions
  end: {
    top: 'top 20%',
    center: 'center center',
    bottom: 'bottom 20%',
  },
  
  // Toggle actions
  toggleActions: {
    playReverse: 'play none none reverse',
    playOnly: 'play none none none',
    playPause: 'play pause resume reverse',
  },
  
  // Scrub values
  scrub: {
    smooth: 1,
    tight: 0.5,
    loose: 2,
  },
} as const;

export const HOVER_EFFECTS = {
  // Lift amounts for hover states
  lift: {
    subtle: -5,
    normal: -8,
    strong: -12,
  },
  
  // Scale amounts
  scale: {
    subtle: 1.02,
    normal: 1.03,
    strong: 1.05,
  },
  
  // Slide amounts
  slide: {
    subtle: 5,
    normal: 8,
    strong: 12,
  },
} as const;

export const ROTATION = {
  // Rotation amounts in degrees
  subtle: 2,
  small: 3,
  medium: 15,
  large: 45,
  spin: 180,
  fullSpin: 360,
  reverseSpin: -360,
} as const;

export const SCALE = {
  // Scale transformations
  shrink: {
    subtle: 0.95,
    normal: 0.9,
    strong: 0.8,
    tiny: 0.5,
    none: 0,
  },
  grow: {
    subtle: 1.1,
    normal: 1.2,
    strong: 1.3,
    large: 1.5,
  },
} as const;

export const BLUR = {
  // Blur amounts
  subtle: 4,
  light: 8,
  medium: 12,
  heavy: 20,
  extreme: 40,
} as const;

export const OPACITY = {
  // Opacity values
  hidden: 0,
  faint: 0.05,
  veryLight: 0.1,
  light: 0.2,
  subtle: 0.3,
  medium: 0.5,
  strong: 0.7,
  veryStrong: 0.9,
  visible: 1,
} as const;

/**
 * Common animation presets
 */
export const ANIMATION_PRESETS = {
  // Fade in from bottom
  fadeInUp: {
    from: {
      y: DISTANCES.large.y,
      opacity: OPACITY.hidden,
    },
    to: {
      y: 0,
      opacity: OPACITY.visible,
      duration: DURATIONS.entrance,
      ease: EASINGS.smooth,
    },
  },
  
  // Scale and fade in
  scaleIn: {
    from: {
      scale: SCALE.shrink.normal,
      opacity: OPACITY.hidden,
    },
    to: {
      scale: 1,
      opacity: OPACITY.visible,
      duration: DURATIONS.entrance,
      ease: EASINGS.bounceSubtle,
    },
  },
  
  // Rotate and scale in (badges)
  spinIn: {
    from: {
      scale: SCALE.shrink.none,
      rotation: ROTATION.fullSpin,
    },
    to: {
      scale: 1,
      rotation: 0,
      duration: DURATIONS.entrance,
      ease: EASINGS.bounce,
    },
  },
  
  // Hover lift effect
  hoverLift: {
    to: {
      y: HOVER_EFFECTS.lift.normal,
      scale: HOVER_EFFECTS.scale.subtle,
      duration: DURATIONS.normal,
      ease: EASINGS.smooth,
    },
    reset: {
      y: 0,
      scale: 1,
      duration: DURATIONS.normal,
      ease: EASINGS.smooth,
    },
  },
  
  // Hover bounce
  hoverBounce: {
    to: {
      y: HOVER_EFFECTS.lift.normal,
      duration: DURATIONS.quick,
      ease: EASINGS.bounce,
    },
    reset: {
      y: 0,
      duration: DURATIONS.quick,
      ease: EASINGS.smooth,
    },
  },
  
  // Continuous float
  float: {
    to: {
      y: -20,
      duration: DURATIONS.breathe,
      repeat: -1,
      yoyo: true,
      ease: EASINGS.inOut,
    },
  },
  
  // Parallax movement
  parallax: {
    to: {
      x: 50,
      ease: EASINGS.linear,
    },
  },
} as const;

/**
 * CSS Animation classes that match GSAP animations
 */
export const CSS_ANIMATIONS = {
  fadeIn: 'animate-fade-in',
  fadeOut: 'animate-fade-out',
  slideInBottom: 'animate-slide-in-bottom',
  slideInTop: 'animate-slide-in-top',
  slideInLeft: 'animate-slide-in-left',
  slideInRight: 'animate-slide-in-right',
  pulse: 'animate-pulse',
  bounce: 'animate-bounce',
  spin: 'animate-spin',
} as const;

/**
 * Transition classes
 */
export const TRANSITIONS = {
  all: 'transition-all',
  colors: 'transition-colors',
  opacity: 'transition-opacity',
  transform: 'transition-transform',
  
  // Durations
  fast: 'duration-200',
  normal: 'duration-300',
  slow: 'duration-500',
  
  // Easings
  smooth: 'ease-out',
  bounce: 'ease-bounce-in',
} as const;

/**
 * Helper function to create GSAP timeline with defaults
 */
export function createTimeline(options = {}) {
  return {
    delay: DURATIONS.quick,
    ease: EASINGS.smooth,
    ...options,
  };
}

/**
 * Helper function for ScrollTrigger configuration
 */
export function createScrollTrigger(trigger: string, options = {}) {
  return {
    trigger,
    start: SCROLL_TRIGGER.start.normal,
    toggleActions: SCROLL_TRIGGER.toggleActions.playReverse,
    ...options,
  };
}

/**
 * Helper function for staggered animations
 */
export function createStagger(amount = STAGGER.normal) {
  return {
    each: amount,
    from: 'start',
  };
}

export default {
  DURATIONS,
  EASINGS,
  STAGGER,
  DISTANCES,
  SCROLL_TRIGGER,
  HOVER_EFFECTS,
  ROTATION,
  SCALE,
  BLUR,
  OPACITY,
  ANIMATION_PRESETS,
  CSS_ANIMATIONS,
  TRANSITIONS,
  createTimeline,
  createScrollTrigger,
  createStagger,
};

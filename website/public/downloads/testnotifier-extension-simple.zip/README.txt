DVSA Queen Extension - Professional Edition
Version: 2.1.1
Build Date: 2025-10-19T13:38:00.388Z

INSTALLATION INSTRUCTIONS:
1. Open Chrome and navigate to chrome://extensions/
2. Enable "Developer mode" in the top right
3. Click "Load unpacked" and select the extracted extension folder
4. The extension icon should appear in your Chrome toolbar

FEATURES:
✅ Advanced stealth technology
✅ Real-time cancellation monitoring
✅ Instructor management system
✅ Multi-pupil support
✅ Risk assessment algorithms
✅ Emergency detection evasion

STEALTH TECHNOLOGY:
• Human-like mouse simulation with Bezier curves
• Adaptive timing randomization
• Detection risk assessment (6-factor analysis)
• Emergency slowdown protocols
• Behavioral pattern camouflage

USAGE:
1. Click the extension icon to open the popup
2. Set up your instructor profile (ADI number required)
3. Add pupils with their licence numbers
4. Navigate to DVSA change booking page
5. The extension will automatically activate
6. Monitor the stealth interface for activity

SAFETY FEATURES:
• Automatic risk detection
• Emergency stop functionality
• Operation blocking for high-risk scenarios
• Session monitoring and health checks

SUPPORT:
For support and updates, contact the development team.

⚠️  IMPORTANT: This extension is for legitimate instructor use only.
    Misuse may violate DVSA terms of service.
